package com.junit.helper;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringHelperTest {
	StringHelper helper = new StringHelper(); //create an instance of StringHelper method
	
	@Test
	public void truncateAInFirst2Positions_1() {		
		assertEquals("CD", helper.truncateAInFirst2Positions("AACD"));	
	}
	@Test
	public void truncateAInFirst2Positions_2() {
		assertEquals("CD", helper.truncateAInFirst2Positions("ACD"));
	}
	
	//ABCD => false, ABAB => true, AB => true, A => false
	@Test
	public void areFirstAndLastTwoCharactersTheSame_BasicNegativeScenario() {
		assertFalse(helper.areFirstAndLastTwoCharactersTheSame("ABCD"));
	}
	@Test
	public void areFirstAndLastTwoCharactersTheSame_BasicPositiveScenario() {
		assertTrue(helper.areFirstAndLastTwoCharactersTheSame("ABAB"));
	}
}
