package com.powermock;

import static org.junit.Assert.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;


//Specific Runner for PowerMock

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("jdk.internal.reflect.*") // Added to suppress initialization errors because of third party jar
@PrepareForTest(SystemUnderTest.class)
public class PowerMockitoMockingConstructorTest {
	
	@Mock
	Dependency dependency;
	
	@InjectMocks
	SystemUnderTest systemUnderTest;
	
	@Mock
	ArrayList mocklist;
	
	@Test
	public void powerMockito_MockingConstructorTest() throws Exception {
		
		when(mocklist.size()).thenReturn(5);
		
		PowerMockito.whenNew(ArrayList.class).withAnyArguments().thenReturn(mocklist);
		
		int size = systemUnderTest.methodUsingAnArrayListConstructor();
	
		//assert
		assertEquals(5, size);
		
	}
}