package com.powermock;

import static org.junit.Assert.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;


//Specific Runner for PowerMock

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("jdk.internal.reflect.*") // Added to suppress initialization errors because of third party jar
@PrepareForTest(UtilityClass.class)
public class MockingStaticMethodTest {
	
	@Mock
	Dependency dependency;
	
	@InjectMocks
	SystemUnderTest systemUnderTest;
	
	@Test
	public void powerMockito_MockingAStaticMethodCall() {
		
		List<Integer> stats = Arrays.asList(1, 2, 3);
		
		when(dependency.retrieveAllStats()).thenReturn(stats);
		
		// Initialize UtilityCLass.class for mocking
		PowerMockito.mockStatic(UtilityClass.class);
		
		
		//Mock UtilityClass.staticMethod
		when(UtilityClass.staticMethod(6)).thenReturn(150);
		
		int result = systemUnderTest.methodCallingAStaticMethod();
		//assert
		assertEquals(150, result);
		
		// Verify the method call
		PowerMockito.verifyStatic();
		UtilityClass.staticMethod(6); //for 5 it will fail: Arguments are different


	}
}