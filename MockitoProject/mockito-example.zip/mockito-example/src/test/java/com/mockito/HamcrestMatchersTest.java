package com.mockito;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.Matchers.*;

import org.junit.Test;

public class HamcrestMatchersTest {

	@Test
	public void test() {
		List<Integer> scores = Arrays.asList(99,101,100,105);
		//scores has 4 items
		assertThat(scores, hasSize(4));
		
        assertThat(scores, hasItems(100, 101));
        
        //every item: > 90 or < 200
        assertThat(scores, everyItem(greaterThan(90)));
        assertThat(scores, everyItem(lessThan(200)));

        // String
        assertThat("", isEmptyString());
        assertThat(null, isEmptyOrNullString());
        
        //array
        
        Integer[] marks = {1, 2, 3};
        assertThat(marks, arrayWithSize(3));
        
        assertThat(marks, arrayContaining(1,2,3)); // if elements not in order then failure
        assertThat(marks, arrayContainingInAnyOrder(1,2,3));
        
        
		
		}

}
