package com.business;

import java.util.ArrayList;
import java.util.List;

import com.data.api.TodoService;

//TodoBusinessImpl: SUT
//TodoService: Dependency

public class TodoBusinessImpl {
	private TodoService todoService;
	
	// Generate Constructor
	public TodoBusinessImpl(TodoService todoService) {
		super();
		this.todoService = todoService;
	}
	
	public List<String> retrieveTodoRelatedToSpring(String user){
		List<String> filteredTodos = new ArrayList<String>();
		List<String> todos = todoService.retrieveTodos(user);
		for(String todo:todos) {
			if(todo.contains("Spring")) {
				filteredTodos.add(todo);
			}
		}
		return filteredTodos;
	}
	
	public void deleteTodosNotRelatedToSpring(String user){
		
		List<String> todos = todoService.retrieveTodos(user);
		for(String todo:todos) {
			if(!todo.contains("Spring")) {
				todoService.deleteTodo(todo);;
			}
		}
	}
	
}
