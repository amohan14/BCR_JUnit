package com.business;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;

public class ListTest {

	@Test
	public void MockListSizeMethod() {
		List listMock = mock(List.class);
		when(listMock.size()).thenReturn(2);
		assertEquals(2,listMock.size());
		assertEquals(2,listMock.size());
		assertEquals(2,listMock.size());
		
	}

	@Test
	public void MockListSize_ReturnMultipleValues() {
		List listMock = mock(List.class);
		when(listMock.size()).thenReturn(2).thenReturn(3); // add the return values 
		assertEquals(2,listMock.size());
		assertEquals(3,listMock.size());
		
	}
	
	@Test
	public void MockListGet() {
		List listMock = mock(List.class);
		//Argument Matcher
		when(listMock.get(anyInt())).thenReturn("Testing Listget()");
		assertEquals("Testing Listget()",listMock.get(0));
		assertEquals("Testing Listget()",listMock.get(1));
		
	}
	
	@Test(expected=RuntimeException.class)
	public void MockList_throwAnException() {
		List listMock = mock(List.class);
	
		when(listMock.get(anyInt())).thenThrow(new RuntimeException("Exception!!"));
		listMock.get(0);
		
	}
	
	@Test(expected=RuntimeException.class)
	public void MockList_MixUp() {
		List listMock = mock(List.class);
	
		when(listMock.subList(anyInt(), 5)).thenThrow(new RuntimeException("Exception!!"));
		listMock.get(10);
	}
}
