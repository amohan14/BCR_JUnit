package com.business;

import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.hamcrest.Matchers.*;

import java.util.List;

import org.junit.Test;

public class ListBDDTest {

	@Test
	public void MockListSizeMethod() {
		List listMock = mock(List.class);
		when(listMock.size()).thenReturn(2);
		assertEquals(2,listMock.size());
		assertEquals(2,listMock.size());
		assertEquals(2,listMock.size());
		
	}

	@Test
	public void MockListSize_ReturnMultipleValues() {
		List listMock = mock(List.class);
		when(listMock.size()).thenReturn(2).thenReturn(3); // add the return values 
		assertEquals(2,listMock.size());
		assertEquals(3,listMock.size());
		
	}
	
	@Test
	public void MockListGet() {
		List listMock = mock(List.class);
		//Argument Matcher
		when(listMock.get(anyInt())).thenReturn("Testing Listget()");
		assertEquals("Testing Listget()",listMock.get(0));
		assertEquals("Testing Listget()",listMock.get(1));
		
	}
	
	@Test(expected=RuntimeException.class)
	public void MockList_throwAnException() {
		List listMock = mock(List.class);
	
		when(listMock.get(anyInt())).thenThrow(new RuntimeException("Exception!!"));
		listMock.get(0);
		
	}
	
	@Test
	public void MockList_usingBDD() {
		//Given
		List<String> listMock = mock(List.class);
	
		given(listMock.get(anyInt())).willReturn("BDD is great");
		//When
		String firstElement = listMock.get(0);
		
		//Then
		assertThat(firstElement, is("BDD is great"));
	}
}
