package com.mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.stub;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class SpyTest {

	@Test
	public void test() {
		List arrayListMock = mock(ArrayList.class);
		assertEquals(0, arrayListMock.size());
		//mock returns default value
		// after stubbing
		stub(arrayListMock.size()).toReturn(5);
		arrayListMock.add("Dummy"); // doesn't change the size o array
		assertEquals(5, arrayListMock.size());
	}

	@Test
	public void test_spy() {
		List arrayListSpy = spy(ArrayList.class);
		assertEquals(0, arrayListSpy.size());
		
		arrayListSpy.add("Dummy"); 
		assertEquals(1, arrayListSpy.size()); // array size increases by 1
		arrayListSpy.remove("Dummy"); 
		assertEquals(0, arrayListSpy.size());
	}
	
	@Test
	public void test_spy_stub() {
		List arrayListSpyStub = spy(ArrayList.class);
		// After stubbing size method always returns 5
		stub(arrayListSpyStub.size()).toReturn(5);
		assertEquals(5, arrayListSpyStub.size()); 
	}
	
	@Test
	public void test_spy_stub_verify() {
		List arrayListSpyStubVerify = spy(ArrayList.class); 
		
		arrayListSpyStubVerify.add("Dummy"); 
		
		verify(arrayListSpyStubVerify).add("Dummy");
		verify(arrayListSpyStubVerify, never()).clear();
	}
}
